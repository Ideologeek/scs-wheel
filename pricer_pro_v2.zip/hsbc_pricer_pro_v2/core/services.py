
import random, time, datetime as dt

class ServiceClient:
    def _lat(self): time.sleep(random.uniform(0.05,0.12))

    def price(self, pricer_model):
        self._lat()
        now = dt.datetime.utcnow().isoformat(timespec="seconds")+"Z"
        return {
            "option_price": round(random.uniform(90,110),4),
            "swap_price": round(random.uniform(95,105),4),
            "note_price": round(random.uniform(98,102),4),
            "asof": now
        }
    def solve(self, pricer_model):
        self._lat()
        return {"status":"Solved","iterations": random.randint(1,6)}

    def create_pims(self, model):
        self._lat(); return {"tradeId": random.randint(100000,999999)}

    def create_sophis(self, model):
        self._lat(); return {"dealId": random.randint(100000,999999)}

    def refresh_market_data(self):
        self._lat(); return {"ok":True}

    def get_tradable_params(self, model):
        self._lat(); return {"params":["notional","legs","dates"]}

    def generate_termsheet(self, model):
        self._lat(); return b"%PDF-1.4\n% Dummy Termsheet PDF"
