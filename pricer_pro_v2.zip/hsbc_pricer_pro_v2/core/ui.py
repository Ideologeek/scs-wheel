
import streamlit as st
import pandas as pd
from typing import Dict, Any, List
from st_aggrid import AgGrid, GridOptionsBuilder, GridUpdateMode
from core.validators import validate_dispersion, business_days_between
from core.services import ServiceClient
from core.settings import get_currencies
svc = ServiceClient()

# some CSS polish
def inject_css():
    st.markdown('''
    <style>
      .pricer-card { border:1px solid #E0E0E0; border-radius:8px; padding:12px; margin-bottom:16px; box-shadow: 0 1px 2px rgba(0,0,0,0.06);}
      .header-strip { background:#fafafa; padding:8px 12px; border-radius:6px; margin-bottom:12px; }
      .price-pill { font-weight:600; margin-right:10px; }
    </style>
    ''', unsafe_allow_html=True)

def command_palette(actions:List[str], dispatch):
    @st.dialog("Command Palette (Ctrl/Cmd+K)")
    def _dlg():
        q = st.text_input("Type a command…")
        for a in [x for x in actions if q.lower() in x.lower()]:
            if st.button(a): dispatch(a)
        if st.button("Close"): st.rerun()
    _dlg()

def build_leg_editor(title:str, leg:Dict[str,Any], enums:Dict[str,List[str]]):
    st.markdown(f"##### {title.title()} leg")
    rows=[]
    n = max(len(leg.get("underlyings",[])), len(leg.get("strikes",[])), len(leg.get("weights",[])), len(leg.get("caps",[])), len(leg.get("n_exp",[])), len(leg.get("lag",[])))
    for i in range(max(1,n)):
        rows.append({
            "ticker": (leg.get("underlyings",[""]*n)[i] if i < len(leg.get("underlyings",[])) else ""),
            "weight": (leg.get("weights",[0.0]*n)[i] if i < len(leg.get("weights",[])) else 0.0),
            "strike": (leg.get("strikes",[0.0]*n)[i] if i < len(leg.get("strikes",[])) else 0.0),
            "cap": (leg.get("caps",[None]*n)[i] if i < len(leg.get("caps",[])) else None),
            "n_exp": (leg.get("n_exp",[0]*n)[i] if i < len(leg.get("n_exp",[])) else 0),
            "lag": (leg.get("lag",[0]*n)[i] if i < len(leg.get("lag",[])) else 0),
        })
    df = pd.DataFrame(rows)
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_default_column(editable=True, resizable=True)
    gb.configure_column("ticker", header_name="Underlying (ticker)")
    gb.configure_column("weight", type=["numericColumn","numberColumnFilter"])
    gb.configure_column("strike", type=["numericColumn"])
    gb.configure_column("cap", type=["numericColumn"])
    gb.configure_column("n_exp", type=["numericColumn"])
    gb.configure_column("lag", type=["numericColumn"])
    grid = AgGrid(df, gridOptions=gb.build(), update_mode=GridUpdateMode.VALUE_CHANGED, height=240, theme="balham")
    out = grid.data
    # write back arrays
    leg["underlyings"] = out["ticker"].astype(str).fillna("").tolist()
    leg["weights"] = pd.to_numeric(out["weight"], errors="coerce").fillna(0.0).tolist()
    leg["strikes"] = pd.to_numeric(out["strike"], errors="coerce").fillna(0.0).tolist()
    leg["caps"] = pd.to_numeric(out["cap"], errors="coerce").where(pd.notnull(out["cap"]), None).tolist()
    leg["n_exp"] = pd.to_numeric(out["n_exp"], errors="coerce").fillna(0).astype(int).tolist()
    leg["lag"] = pd.to_numeric(out["lag"], errors="coerce").fillna(0).astype(int).tolist()
    # per-leg toggles / enums
    st.checkbox("Use net dividends", key=f"use_net_div_{title}", value=leg.get("use_net_div", False), on_change=lambda:None)
    leg["use_net_div"] = st.session_state.get(f"use_net_div_{title}", False)
    div_enum = enums.get("DividendAdjustmentType", [])
    # default to proto default DAT_DENOMINATOR if not set
    default = leg.get("dividend_adj_type") or "DAT_DENOMINATOR"
    idx = div_enum.index(default) if default in div_enum else 0
    leg["dividend_adj_type"] = st.selectbox("Dividend adjustment", div_enum, index=idx, key=f"divadj_{title}")
    return leg

def build_corridor_editor(leg:Dict[str,Any], enums:Dict[str,List[str]], key:str):
    st.markdown("###### Corridor mapping")
    cm = leg.get("corridor_mapping", {}) or {}
    # Use proto defaults if missing
    lag_enum = enums.get("CorridorLagType", [])
    perf_enum = enums.get("CorridorPerfType", [])
    type_enum = enums.get("CorridorType", [])
    conv_enum = enums.get("CorridorConvention", [])
    lag_default = cm.get("lag_type", "CLT_LAG_RETURN"); lag_idx = lag_enum.index(lag_default) if lag_default in lag_enum else 0
    perf_default = cm.get("perf_type", "CPT_BASKET"); perf_idx = perf_enum.index(perf_default) if perf_default in perf_enum else 0
    type_default = cm.get("type", "CT_CORRIDOR"); type_idx = type_enum.index(type_default) if type_default in type_enum else 0
    conv_default = cm.get("convention", "CC_T"); conv_idx = conv_enum.index(conv_default) if conv_default in conv_enum else 0
    cm["lag_type"] = st.selectbox("Lag type", lag_enum, index=lag_idx, key=f"lagtype_{key}")
    cm["perf_type"] = st.selectbox("Perf type", perf_enum, index=perf_idx, key=f"perftype_{key}")
    cm["type"] = st.selectbox("Type", type_enum, index=type_idx, key=f"ctype_{key}")
    cm["convention"] = st.selectbox("Convention", conv_enum, index=conv_idx, key=f"conv_{key}")
    cm["upper_bound"] = st.number_input("Upper bound", value=float(cm.get("upper_bound", 999999.0)), key=f"ub_{key}")
    cm["lower_bound"] = st.number_input("Lower bound", value=float(cm.get("lower_bound", 0.0)), key=f"lb_{key}")
    leg["corridor_mapping"] = cm

def card_header(pricer, prices:Dict[str,Any]|None):
    st.markdown("<div class='header-strip'>", unsafe_allow_html=True)
    cols = st.columns([6,2,1,1,1])
    cols[0].markdown(f"### Dispersion — {pricer['id']}")
    if prices:
        cols[0].markdown(f"<span class='price-pill'>Option {prices['option_price']}</span><span class='price-pill'>Swap {prices['swap_price']}</span><span class='price-pill'>Note {prices['note_price']}</span> _as of {prices['asof']}_", unsafe_allow_html=True)
    active = st.session_state.get(f"active_{pricer['id']}", pricer.get("active", True))
    st.session_state[f"active_{pricer['id']}"] = cols[1].toggle("Active", value=active, key=f"active_toggle_{pricer['id']}")
    pricer["active"] = st.session_state[f"active_{pricer['id']}"]
    if cols[2].button("⚙️", key=f"gear_{pricer['id']}"): gear_dialog(pricer)
    if cols[3].button("Duplicate", key=f"dup_{pricer['id']}"):
        st.session_state.pricers.append({**pricer, "id": pricer['id'] + "_copy"})
        st.rerun()
    if cols[4].button("✖", key=f"del_{pricer['id']}"):
        st.session_state.pricers = [p for p in st.session_state.pricers if p['id'] != pricer['id']]
        st.rerun()
    st.markdown("</div>", unsafe_allow_html=True)

def gear_dialog(pricer):
    @st.dialog(f"Actions — {pricer['id']}")
    def _dlg():
        for a in ["Compute","Solve","Backtest","Advanced Analytics","Create in PIMS","Create in Sophis","Save JSON","Load JSON","Toggle Active","Delete"]:
            if st.button(a):
                st.session_state.pending_action = (a, pricer['id']); st.rerun()
        if st.button("Close"): st.rerun()
    _dlg()

def render_dispersion_card(pricer, proto_info):
    enums = proto_info["enums"]
    model = pricer.setdefault("model", {})
    base = model.setdefault("base", {})
    left = model.setdefault("left", {})
    right = model.setdefault("right", {})
    prices = pricer.get("prices")
    st.markdown("<div class='pricer-card'>", unsafe_allow_html=True)
    card_header(pricer, prices)

    st.markdown("#### Base")
    ccols = st.columns(5)
    base["start_date"] = ccols[0].text_input("Start Date (YYYY-MM-DD)", value=base.get("start_date",""))
    base["end_date"] = ccols[1].text_input("End Date (YYYY-MM-DD)", value=base.get("end_date",""))
    base["settlement_final_date"] = ccols[2].text_input("Maturity (YYYY-MM-DD)", value=base.get("settlement_final_date",""))
    base["settlement_payment_date"] = ccols[3].text_input("Settlement Date (YYYY-MM-DD)", value=base.get("settlement_payment_date",""))
    currencies = get_currencies()
    default_ccy = base.get("payment_currency", currencies[0])
    base["payment_currency"] = ccols[4].selectbox("Currency", options=currencies, index=currencies.index(default_ccy) if default_ccy in currencies else 0)

    c2 = st.columns(3)
    base["notional"] = c2[0].number_input("Notional", value=float(base.get("notional",100.0)))
    base["contract_size"] = c2[1].number_input("Contract Size", value=float(base.get("contract_size",1.0)))
    base["has_performance_payment"] = c2[2].toggle("Has Performance Payment", value=bool(base.get("has_performance_payment", True)))

    with st.expander("Advanced"):
        adv1 = st.columns(4)
        model["is_geometric"] = adv1[0].toggle("Geometric", value=bool(model.get("is_geometric", False)))
        model["is_corridor"] = adv1[1].toggle("Corridor", value=bool(model.get("is_corridor", False)))
        model["is_global_cap_floor"] = adv1[2].toggle("Global Cap/Floor", value=bool(model.get("is_global_cap_floor", False)))
        disp_enum = enums.get("DispersionType", [])
        disp_default = model.get("dispersion_type", "DT_VOL")
        model["dispersion_type"] = adv1[3].selectbox("Dispersion Type", disp_enum, index=disp_enum.index(disp_default) if disp_default in disp_enum else 0)
        adv2 = st.columns(4)
        model["annualization_factor"] = adv2[0].number_input("Annualization Factor", value=float(model.get("annualization_factor",252.0)))
        model["alpha"] = adv2[1].number_input("Alpha", value=float(model.get("alpha",1.0)))
        model["enforce_exact_payoff"] = adv2[2].toggle("Enforce Exact Payoff", value=bool(model.get("enforce_exact_payoff", False)))
        model["use_same_calendar"] = adv2[3].toggle("Use Same Calendar", value=bool(model.get("use_same_calendar", False)))

    c3 = st.columns(2)
    with c3[0]:
        model["left"] = build_leg_editor("left", left, enums)
        if model.get("is_corridor"):
            build_corridor_editor(left, enums, key=f"left_{pricer['id']}")
    with c3[1]:
        model["right"] = build_leg_editor("right", right, enums)
        if model.get("is_corridor"):
            build_corridor_editor(right, enums, key=f"right_{pricer['id']}")

    errs = validate_dispersion(model)
    if errs:
        st.error("\n".join([f"• {e}" for e in errs]))
    else:
        st.success("All inputs valid.")
    st.markdown("</div>", unsafe_allow_html=True)

def top_ribbon():
    actions = ["Pricing","Clean","Get Dates","Refresh Market Data","Get Tradable Params","Save","Load","Compute","Solve","Backtest","Advanced Analytics","Create in PIMS","Create in Sophis","Generate Termsheet","Command Palette"]
    cols = st.columns(len(actions))
    for i,a in enumerate(actions):
        if cols[i].button(a):
            st.session_state.pending_action = (a, None); st.rerun()
    return actions

def handle_action(action:str, target_id:str|None):
    targets = []
    if target_id:
        targets = [p for p in st.session_state.pricers if p["id"]==target_id]
    else:
        targets = [p for p in st.session_state.pricers if p.get("active", True)]

    if action=="Command Palette":
        command_palette(["Compute","Solve","Backtest","Advanced Analytics","Create in PIMS","Create in Sophis","Generate Termsheet","Save","Load","Clean","Get Dates"], lambda a: handle_action(a, None))
        return

    if action=="Save":
        import json
        s = json.dumps(st.session_state.pricers, indent=2)
        st.download_button("Download pricers.json", s, file_name="pricers.json", mime="application/json"); return

    if action=="Load":
        up = st.file_uploader("Upload pricers.json", type=["json"])
        if up:
            import json
            st.session_state.pricers = json.load(up)
        return

    for p in targets:
        model = p.setdefault("model",{})
        if action=="Compute":
            p["prices"] = svc.price(model); st.toast(f"Priced {p['id']}")
        elif action=="Solve":
            p["solve"] = svc.solve(model); st.toast(f"Solved {p['id']}")
        elif action=="Create in PIMS":
            p["pims"] = svc.create_pims(model); st.toast(f"PIMS trade: {p['pims']['tradeId']}")
        elif action=="Create in Sophis":
            p["sophis"] = svc.create_sophis(model); st.toast(f"Sophis deal: {p['sophis']['dealId']}")
        elif action=="Refresh Market Data":
            svc.refresh_market_data(); st.toast("Market data refreshed")
        elif action=="Get Tradable Params":
            p["tradable"]=svc.get_tradable_params(model)
        elif action=="Generate Termsheet":
            pdf = svc.generate_termsheet(model)
            st.download_button(f"Download Termsheet — {p['id']}", pdf, file_name=f"termsheet_{p['id']}.pdf")
        elif action=="Backtest":
            st.session_state.backtest_target = p['id']; st.switch_page("pages/3_Backtest.py")
        elif action=="Advanced Analytics":
            st.session_state.analytics_target = p['id']; st.toast("See analytics in card.")
        elif action=="Clean":
            p["model"]={}
        elif action=="Get Dates":
            # populate n_exp from business days count
            base = model.get("base",{})
            s = base.get("start_date"); e = base.get("end_date")
            if s and e:
                nbd = business_days_between(s, e)
                for side in ["left","right"]:
                    leg = model.setdefault(side,{})
                    n = max(len(leg.get("underlyings",[])),1)
                    leg["n_exp"] = [nbd]*n
                st.toast(f"Set n_exp = {nbd} for all leg rows")
