
from typing import List, Dict, Any
import datetime as dt
import pandas as pd

def is_iso_date(s:str)->bool:
    try:
        dt.date.fromisoformat(s)
        return True
    except Exception:
        return False

def business_days_between(start:str, end:str)->int:
    try:
        s = dt.date.fromisoformat(start)
        e = dt.date.fromisoformat(end)
        if s>=e: return 0
        # count business days using pandas
        return len(pd.bdate_range(s, e))
    except Exception:
        return 0

def validate_dispersion(model:Dict[str,Any])->List[str]:
    errs=[]
    base=model.get("base",{})
    start=base.get("start_date") or ""
    end=base.get("end_date") or ""
    maturity=base.get("settlement_final_date") or ""
    settlement=base.get("settlement_payment_date") or ""
    if not (is_iso_date(start) and is_iso_date(end)): errs.append("Start/End date must be ISO-8601.")
    else:
        if start>=end: errs.append("Start date must be < End date.")
    if maturity and is_iso_date(maturity) and is_iso_date(end):
        if maturity<end: errs.append("Maturity (settlement_final_date) must be >= End date.")
    if settlement and is_iso_date(settlement) and is_iso_date(start):
        if settlement<start: errs.append("Settlement payment date must be >= Start date.")
    # legs
    for side in ["left","right"]:
        leg=model.get(side,{})
        under=leg.get("underlyings",[])
        strikes=leg.get("strikes",[])
        weights=leg.get("weights",[])
        if len(under)==0: errs.append(f"{side.title()} leg needs at least one component.")
        if len(strikes)!=len(under): errs.append(f"{side.title()} leg: strikes length must match underlyings.")
        if len(weights)!=len(under): errs.append(f"{side.title()} leg: weights length must match underlyings.")
        for i,s in enumerate(strikes):
            try:
                if float(s)<=0: errs.append(f"{side.title()} leg row {i+1}: strike must be > 0.")
            except Exception:
                errs.append(f"{side.title()} leg row {i+1}: strike invalid.")
    return errs
