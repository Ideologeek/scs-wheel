
import re, pathlib
from typing import Dict, Any, List

ENUM_RE = re.compile(r'enum\s+(\w+)\s*\{([\s\S]*?)\}', re.MULTILINE)
FIELD_RE = re.compile(r'(optional|repeated)\s+(\w[\w\.]+)\s+(\w+)\s*=\s*(\d+)\s*(\[[^\]]*\])?\s*;', re.MULTILINE)
DEFAULT_RE = re.compile(r'default\s*=\s*([\w\.\-\d]+)')

def parse_proto(path: pathlib.Path) -> Dict[str, Any]:
    text = path.read_text()
    enums = {}
    for name, body in ENUM_RE.findall(text):
        items = []
        for line in body.splitlines():
            line=line.strip()
            if not line or line.startswith("//"): continue
            m = re.match(r'(\w+)\s*=\s*([0-9]+)\s*;', line)
            if m:
                items.append(m.group(1))
        enums[name] = items

    messages = {}
    for msg in re.finditer(r'message\s+(\w+)\s*\{([\s\S]*?)\}', text, re.MULTILINE):
        mname = msg.group(1)
        body = msg.group(2)
        fields=[]
        for f in FIELD_RE.findall(body):
            label, ftype, fname, order, opts = f
            default=None
            if opts:
                dm = DEFAULT_RE.search(opts)
                if dm:
                    default = dm.group(1)
            fields.append({
                "label": label,
                "type": ftype,
                "name": fname,
                "order": int(order),
                "default": default
            })
        messages[mname] = {"fields": sorted(fields, key=lambda x: x["order"])}
    return {"enums": enums, "messages": messages}
