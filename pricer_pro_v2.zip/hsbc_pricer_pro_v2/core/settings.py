
import json, pathlib, os
def get_currencies():
    path = pathlib.Path("assets/currencies.json")
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            pass
    # fallback
    return ["USD","EUR","GBP","CHF","JPY","AUD","CAD","HKD","SGD","CNY"]
