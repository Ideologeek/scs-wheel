
import streamlit as st, uuid, pathlib
from core.proto_parser import parse_proto
from core.ui import render_dispersion_card, top_ribbon, handle_action, inject_css

st.title("Pricing")
inject_css()

if "pricers" not in st.session_state: st.session_state.pricers=[]
if "pending_action" not in st.session_state: st.session_state.pending_action=None

actions = top_ribbon()

c = st.columns([2,10])
with c[0]:
    st.markdown("### Pricers")
    if st.button("Add product"):
        st.session_state.pricers.append({"id": uuid.uuid4().hex[:8], "product":"Dispersion", "active": True, "model": {}})
        st.rerun()
    if st.button("Duplicate product"):
        if st.session_state.pricers:
            p = st.session_state.pricers[-1]
            st.session_state.pricers.append({**p, "id": uuid.uuid4().hex[:8]})
            st.rerun()
    st.markdown("### Backtesting")
    if st.button("Open Backtest"):
        if st.session_state.pricers:
            st.session_state.backtest_target = st.session_state.pricers[-1]["id"]
            st.switch_page("pages/3_Backtest.py")
    st.divider()
    st.write("All pricers:")
    for p in st.session_state.pricers:
        st.write(f"- {p['product']} — {p['id']} {'(active)' if p.get('active',True) else '(inactive)'}")

with c[1]:
    proto_info = parse_proto(pathlib.Path("proto/dispersion.proto"))
    cols = st.columns(2)
    for i, pr in enumerate(st.session_state.pricers):
        with cols[i % 2]:
            if pr["product"]=="Dispersion":
                render_dispersion_card(pr, proto_info)

if st.session_state.pending_action:
    action, target = st.session_state.pending_action
    st.session_state.pending_action=None
    handle_action(action, target)
