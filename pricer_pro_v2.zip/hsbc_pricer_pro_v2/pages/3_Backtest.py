
import streamlit as st, pandas as pd, numpy as np, datetime as dt
st.title("Backtest")

pid = st.session_state.get("backtest_target")
if not pid:
    st.warning("Launch backtest from Pricing page.")
    st.stop()

dates = pd.date_range(dt.date.today()-dt.timedelta(days=365*2), dt.date.today(), freq="B")
pnl = pd.Series(np.random.normal(0,1,len(dates))).cumsum()
df = pd.DataFrame({"date": dates, "pnl": pnl})

ret = pnl.iloc[-1] - pnl.iloc[0]
dd = (pnl.cummax()-pnl).max()
vol = pnl.diff().std()*np.sqrt(252)
hit = (pnl.diff()>0).mean()

c = st.columns(4)
c[0].metric("Total Return", f"{ret:.2f}")
c[1].metric("Vol (ann.)", f"{vol:.2f}")
c[2].metric("Max Drawdown", f"{dd:.2f}")
c[3].metric("Hit Ratio", f"{hit:.1%}")

st.line_chart(df.set_index("date")["pnl"])
st.download_button("Download CSV", df.to_csv(index=False), file_name=f"backtest_{pid}.csv")
