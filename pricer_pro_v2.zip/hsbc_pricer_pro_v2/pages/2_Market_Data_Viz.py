
import streamlit as st, pandas as pd, numpy as np
st.title("Market Data Visualisation")
st.info("Connect your internal market data here. Below is a stub.")
st.area_chart(pd.DataFrame(np.random.randn(200,3), columns=list("ABC")))
