
from core.proto_parser import parse_proto
from pathlib import Path
def test_parse():
    info = parse_proto(Path("proto/dispersion.proto"))
    assert "DispersionProduct" in info["messages"]
    assert "DividendAdjustmentType" in info["enums"]
