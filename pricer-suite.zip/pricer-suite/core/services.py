
import os, time, random, base64
from typing import Dict
import pandas as pd
class ServiceClient:
    def __init__(self):
        self.base_url = os.getenv("SERVICE_BASE_URL","https://api.placeholder.internal")

    def _latency(self):
        time.sleep(random.uniform(0.05,0.15))

    # Pricing
    def price(self, pricer) -> Dict[str,float]:
        self._latency()
        return {
            "option_price": round(random.uniform(90,110),4),
            "swap_price": round(random.uniform(95,105),4),
            "note_price": round(random.uniform(98,102),4),
        }

    def solve(self, pricer)->Dict:
        self._latency()
        return {"status":"Solved","iterations":random.randint(1,10)}

    # Market data
    def refresh_market_data(self):
        self._latency()
        return {"refreshed":True}

    def get_tradable_params(self, pricer):
        self._latency()
        return {"tradable":["notional","coupon_percent"]}

    # Systems integration
    def create_pims(self, pricer):
        self._latency()
        return {"tradeId": random.randint(100000,999999)}

    def create_sophis(self, pricer):
        self._latency()
        return {"dealId": random.randint(100000,999999)}

    # Termsheet
    def generate_termsheet(self, pricer)->bytes:
        self._latency()
        # dummy PDF bytes
        return b"%PDF-1.4 Dummy PDF bytes%EOF"
