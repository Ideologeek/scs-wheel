
import pandas as pd, numpy as np, datetime as dt, random

def backtest(pricer, years:int=2):
    today = dt.date.today()
    start = today - dt.timedelta(days=years*365)
    dates = pd.date_range(start, today, freq='B')
    # simulate pnl distribution overlaying random walk around current note price if available
    base = pricer.data.get("prices",{}).get("note_price",100)
    pnl = base + np.random.normal(0,1,len(dates)).cumsum()
    return pd.DataFrame({"date":dates,"pnl":pnl})

def advanced_analytics(pricer):
    # Dummy Greeks
    greeks = {
        "Delta": np.random.uniform(-1,1),
        "Gamma": np.random.uniform(0,1),
        "Vega": np.random.uniform(0,2),
        "Theta": np.random.uniform(-2,0),
        "Rho": np.random.uniform(-1,1),
    }
    return pd.DataFrame(list(greeks.items()), columns=["Greek","Value"])
