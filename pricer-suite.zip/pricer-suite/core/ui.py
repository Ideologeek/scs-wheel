
import streamlit as st, json
from typing import List, Dict, Any
from core.pricer import Pricer
from core.services import ServiceClient
from core.analytics import advanced_analytics, backtest
import pandas as pd

svc = ServiceClient()

# ----------------- form builder -------------------
def render_dynamic_form(pricer:Pricer):
    schema = pricer.schema
    mandatory = [f for f in schema['fields'] if f['required']]
    advanced = [f for f in schema['fields'] if not f['required']]
    st.write("### Inputs")
    _form_fields(pricer, mandatory)
    with st.expander("Advanced parameters"):
        _form_fields(pricer, advanced)

def _form_fields(pricer:Pricer, fields:List[Dict[str,Any]]):
    for f in fields:
        key = f"{pricer.id}_{f['name']}"
        val = pricer.data.get(f['name'])
        if f['type']=="float":
            pricer.data[f['name']] = st.number_input(f['name'], value=val or 0.0, key=key)
        elif f['type']=="int":
            pricer.data[f['name']] = st.number_input(f['name'], value=val or 0, key=key, step=1, format="%d")
        elif f['type']=="bool":
            pricer.data[f['name']] = st.checkbox(f['name'], value=val or False, key=key)
        elif f['type']=="str":
            pricer.data[f['name']] = st.text_input(f['name'], value=val or "", key=key)
        else:
            pricer.data[f['name']] = st.text_input(f['name'], value=val or "", key=key)

# -------------- ribbon ---------------------------
RIBBON_ACTIONS = ["Clean","Get Dates","Refresh Market Data","Get Tradable Params","Save","Load","Compute","Solve","Backtest","Advanced Analytics","Create in PIMS","Create in Sophis","Generate Term-sheet"]

def render_ribbon():
    st.markdown("### Global Actions")
    cols = st.columns(len(RIBBON_ACTIONS))
    for i,label in enumerate(RIBBON_ACTIONS):
        if cols[i].button(label):
            _handle_ribbon(label)

def _handle_ribbon(action:str):
    active_pricers:List[Pricer] = [p for p in st.session_state.pricers if p.active]
    if action=="Load":
        uploaded = st.file_uploader("Upload JSON",type=["json"])
        if uploaded:
            data = json.load(uploaded)
            st.session_state.pricers = [Pricer.from_json(d) for d in data]
        return
    if action=="Save":
        json_str = json.dumps([p.to_json() for p in active_pricers], indent=2, default=str)
        st.download_button("Download", data=json_str, file_name="pricers.json", mime="application/json")
        return
    for p in active_pricers:
        _dispatch_single(p, action)

def _dispatch_single(pricer:Pricer, action:str):
    if action=="Compute":
        prices = svc.price(pricer)
        pricer.data["prices"]=prices
    elif action=="Solve":
        pricer.data["solve"]=svc.solve(pricer)
    elif action=="Create in PIMS":
        pricer.data["pims"]=svc.create_pims(pricer)
    elif action=="Create in Sophis":
        pricer.data["sophis"]=svc.create_sophis(pricer)
    elif action=="Refresh Market Data":
        svc.refresh_market_data()
    elif action=="Get Tradable Params":
        pricer.data["tradable"]=svc.get_tradable_params(pricer)
    elif action=="Generate Term-sheet":
        pdf = svc.generate_termsheet(pricer)
        st.download_button(f"Term-sheet {pricer.id}", data=pdf, file_name=f"termsheet_{pricer.id}.pdf")
    elif action=="Backtest":
        st.session_state["backtest_target"]=pricer.id
        st.switch_page("pages/3_Backtest.py")
    elif action=="Advanced Analytics":
        df = advanced_analytics(pricer)
        st.dataframe(df, use_container_width=True)
    elif action=="Clean":
        pricer.data = {}
    elif action=="Get Dates":
        pass  # placeholder

# ------------- pricer container -------------------
def pricer_container(pricer:Pricer):
    alpha="1.0" if pricer.active else "0.5"
    with st.container():
        st.markdown(f"<div style='border:1px solid #8A8D8D; padding:10px; opacity:{alpha};'>", unsafe_allow_html=True)
        cols=st.columns([6,1,1,1,1])
        cols[0].markdown(f"#### {pricer.product} ({pricer.id})")
        if cols[1].button("⚙️", key=f"gear_{pricer.id}"):
            _modal_actions(pricer)
        if cols[2].button("A", help="Toggle active", key=f"act_{pricer.id}"):
            pricer.active = not pricer.active
        if cols[3].button("🗑️", key=f"del_{pricer.id}"):
            st.session_state.pricers.remove(pricer)
            st.experimental_rerun()
        if cols[4].button("Test", key=f"bt_{pricer.id}"):
            st.session_state["backtest_target"]=pricer.id
            st.switch_page("pages/3_Backtest.py")
        render_dynamic_form(pricer)
        # show price results if exist
        if pricer.data.get("prices"):
            st.success(f"Option: {pricer.data['prices']['option_price']} | Swap: {pricer.data['prices']['swap_price']} | Note: {pricer.data['prices']['note_price']}")
        st.markdown("</div>", unsafe_allow_html=True)

# -------- modal per pricer ----------
def _modal_actions(pricer:Pricer):
    with st.modal(f"Actions {pricer.product} {pricer.id}"):
        for act in ["Compute","Solve","Backtest","Advanced Analytics","Create in PIMS","Create in Sophis","Save JSON","Load JSON","Toggle Active","Delete"]:
            if st.button(act):
                if act=="Save JSON":
                    json_str = json.dumps(pricer.to_json(), indent=2, default=str)
                    st.download_button("Download", json_str, file_name=f"pricer_{pricer.id}.json")
                elif act=="Load JSON":
                    up = st.file_uploader("Upload single pricer JSON", key=f"u_{pricer.id}")
                    if up:
                        data=json.load(up)
                        pricer.data = data.get("data",{})
                elif act=="Toggle Active":
                    pricer.active = not pricer.active
                elif act=="Delete":
                    st.session_state.pricers.remove(pricer)
                    st.experimental_rerun()
                else:
                    _dispatch_single(pricer, act)
        st.button("Close")
