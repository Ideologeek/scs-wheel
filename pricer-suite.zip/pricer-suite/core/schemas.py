
import re, pathlib, json
from typing import List, Dict

SCHEMA_CACHE: Dict[str, dict] = {}

TYPE_MAP = {
    'string': 'str',
    'double': 'float',
    'bool': 'bool',
    'int32': 'int',
    'int64': 'int',
}

def _parse_proto(file_path: pathlib.Path) -> dict:
    fields = []
    for line in file_path.read_text().splitlines():
        line = line.strip()
        m = re.match(r'(repeated\s+)?(\w+)\s+(\w+)\s*=\s*(\d+);.*', line)
        if m:
            repeated, ptype, name, _ = m.groups()
            pytype = TYPE_MAP.get(ptype, 'str')
            is_list = repeated is not None
            fields.append({
                'name': name,
                'type': pytype,
                'required': True if len(fields)<6 else False,  # first 6 mandatory heuristic
                'repeated': is_list,
            })
    return {'fields': fields}

def load_schema(product_key:str) -> dict:
    if product_key in SCHEMA_CACHE:
        return SCHEMA_CACHE[product_key]
    base = pathlib.Path(__file__).resolve().parent.parent / 'proto'
    if product_key == "Autocallable Decrement":
        path = base / 'wealth' / 'autocallable_decrement.proto'
    elif product_key == "Dispersion":
        path = base / 'institutional' / 'dispersion.proto'
    else:
        raise ValueError("Unknown product")
    schema = _parse_proto(path)
    SCHEMA_CACHE[product_key] = schema
    return schema
