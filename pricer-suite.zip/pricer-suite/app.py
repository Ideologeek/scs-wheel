
import streamlit as st
st.set_page_config(page_title="HSBC Pricer Suite", page_icon="💼", layout="wide")
st.image("assets/hsbc_logo.svg", width=120)
st.write("# HSBC Pricer Suite")
st.write("Select a module from the sidebar.")
