
from core.pricer import Pricer
def test_json():
    p = Pricer(family="Wealth", product="Autocallable Decrement")
    j = p.to_json()
    assert j['product']=="Autocallable Decrement"
    p2 = Pricer.from_json(j)
    assert p2.product==p.product
