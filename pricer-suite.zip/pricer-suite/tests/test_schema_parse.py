
from core.schemas import load_schema
def test_schema():
    s = load_schema("Autocallable Decrement")
    assert 'fields' in s and len(s['fields'])>0
