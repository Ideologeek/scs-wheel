
import streamlit as st
from core.pricer import Pricer
from core.analytics import backtest
import pandas as pd

st.title("Backtest")

target = st.session_state.get("backtest_target")
if target is None:
    st.warning("Launch a backtest from the Pricing page.")
    st.stop()

# find pricer
prisers = [p for p in st.session_state.get("pricers",[]) if p.id==target]
if not prisers:
    st.error("Pricer not found")
    st.stop()
pricer = prisers[0]
st.subheader(f"{pricer.product} ({pricer.id})")

df = backtest(pricer)
st.line_chart(df.set_index("date")["pnl"])
with st.expander("Data"):
    st.dataframe(df, use_container_width=True)
    csv = df.to_csv(index=False).encode()
    st.download_button("Download CSV", data=csv, file_name=f"backtest_{pricer.id}.csv")
