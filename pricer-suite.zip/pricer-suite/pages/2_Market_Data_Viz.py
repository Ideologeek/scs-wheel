
import streamlit as st, pandas as pd, numpy as np
st.title("Market Data Visualisation (stub)")
st.info("Connect to market data feed here.")
df = pd.DataFrame(np.random.randn(100,3), columns=list("ABC"))
st.area_chart(df)
