
import streamlit as st
from core.pricer import Pricer
from core.ui import render_ribbon, pricer_container

if "pricers" not in st.session_state:
    st.session_state.pricers = []

st.title("Pricing Workbench")

render_ribbon()

if st.button("➕ Add Pricer"):
    with st.modal("Add New Pricer"):
        families = {"Wealth":["Autocallable Decrement"],"Institutional":["Dispersion"]}
        fam = st.selectbox("Family", families.keys())
        prod = st.selectbox("Product", families[fam])
        if st.button("Create"):
            st.session_state.pricers.append(Pricer(family=fam, product=prod))
            st.experimental_rerun()

for p in st.session_state.pricers:
    pricer_container(p)
