
import streamlit as st, json
from core.pricer import Pricer
from core.services import ServiceClient
from core.analytics import advanced_analytics
svc=ServiceClient()

def _field(p,f):
    key=f'{p.id}_{f["name"]}'
    val=p.data.get(f['name'])
    if f['type']=='float':
        p.data[f['name']]=st.number_input(f['name'],value=val or 0.0,key=key)
    else:
        p.data[f['name']]=st.text_input(f['name'],value=val or '',key=key)

def render_form(p:Pricer):
    req=[f for f in p.schema['fields'] if f['required']]
    adv=[f for f in p.schema['fields'] if not f['required']]
    for f in req: _field(p,f)
    with st.expander('Advanced'): 
        for f in adv: _field(p,f)

ACTIONS=['Clean','Refresh Market Data','Get Tradable Params','Save','Load','Compute','Solve','Backtest','Advanced Analytics','Create in PIMS','Create in Sophis','Generate Term-sheet']
def ribbon():
    cols=st.columns(len(ACTIONS))
    for i,l in enumerate(ACTIONS):
        if cols[i].button(l): _handle(l)

def _handle(action):
    active=[p for p in st.session_state.pricers if p.active]
    if action=='Save':
        st.download_button('Download',json.dumps([p.to_json() for p in active]),file_name='pricers.json');return
    if action=='Load':
        up=st.file_uploader('Upload',type=['json'])
        if up: st.session_state.pricers=[Pricer.from_json(d) for d in json.load(up)];return
    for p in active:_dispatch(p,action)

def _dispatch(p,act):
    if act=='Compute': p.data['prices']=svc.price(p)
    elif act=='Solve': svc.solve(p)
    elif act=='Create in PIMS': svc.create_pims(p)
    elif act=='Create in Sophis': svc.create_sophis(p)
    elif act=='Refresh Market Data': svc.refresh_market_data()
    elif act=='Get Tradable Params': p.data['tradable']=svc.get_tradable_params(p)
    elif act=='Generate Term-sheet': st.download_button(f'TS {p.id}',svc.generate_termsheet(p),file_name=f'ts_{p.id}.pdf')
    elif act=='Backtest': st.session_state['backtest_target']=p.id; st.switch_page('pages/3_Backtest.py')
    elif act=='Advanced Analytics': st.dataframe(advanced_analytics(p))
    elif act=='Clean': p.data={}

def gear_dialog(p):
    @st.dialog(f'Actions {p.product} {p.id}')
    def dlg():
        for act in ['Compute','Solve','Backtest','Advanced Analytics','Create in PIMS','Create in Sophis','Toggle Active','Delete']:
            if st.button(act):
                if act=='Toggle Active': p.active=not p.active
                elif act=='Delete': st.session_state.pricers.remove(p); st.rerun()
                else: _dispatch(p,act)
        if st.button('Close'): st.rerun()
    dlg()

def add_pricer_dialog():
    @st.dialog('Add pricer')
    def add():
        fams={'Wealth':['Autocallable Decrement'],'Institutional':['Dispersion']}
        fam=st.selectbox('Family',fams.keys())
        prod=st.selectbox('Product',fams[fam])
        if st.button('Create'): st.session_state.pricers.append(Pricer(family=fam,product=prod)); st.rerun()
    add()

def pricer_container(p):
    with st.container():
        st.write(f'### {p.product} ({p.id}) {"[inactive]" if not p.active else ""}')
        c1,c2=st.columns([1,5])
        if c1.button('⚙️',key=f'g_{p.id}'): gear_dialog(p)
        render_form(p)
        if p.data.get('prices'):
            st.success(str(p.data['prices']))
