
import pandas as pd, numpy as np, datetime as dt, random
def backtest(p,years=2):
    end=dt.date.today()
    start=end-dt.timedelta(days=365*years)
    dates=pd.date_range(start,end,freq='B')
    pnl=np.random.normal(0,1,len(dates)).cumsum()
    return pd.DataFrame({'date':dates,'pnl':pnl})
def advanced_analytics(p):
    import numpy as np
    d={'Delta':np.random.uniform(-1,1),'Gamma':np.random.uniform(0,1),'Vega':np.random.uniform(0,2),'Theta':np.random.uniform(-2,0),'Rho':np.random.uniform(-1,1)}
    import pandas as pd
    return pd.DataFrame(d.items(),columns=['Greek','Value'])
