
from dataclasses import dataclass, field, asdict
from typing import Dict, Any
import uuid, datetime as dt
from core.schemas import load_schema

@dataclass
class Pricer:
    family:str
    product:str
    id:str=field(default_factory=lambda:uuid.uuid4().hex[:8])
    active:bool=True
    data:Dict[str,Any]=field(default_factory=dict)
    created:dt.datetime=field(default_factory=dt.datetime.utcnow)

    @property
    def schema(self): return load_schema(self.product)
    def to_json(self): return asdict(self)
    @classmethod
    def from_json(cls,d): return cls(**{k:d[k] for k in d if k in cls.__dataclass_fields__})
