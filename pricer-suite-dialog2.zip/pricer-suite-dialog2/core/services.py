
import random, time
class ServiceClient:
    def _lat(self): time.sleep(random.uniform(0.05,0.1))
    def price(self,p): self._lat(); return {'option_price':round(random.uniform(90,110),4),'swap_price':round(random.uniform(95,105),4),'note_price':round(random.uniform(98,102),4)}
    def solve(self,p): self._lat(); return {'status':'ok'}
    def create_pims(self,p): self._lat(); return {'tradeId': random.randint(100000,999999)}
    def create_sophis(self,p): self._lat(); return {'dealId': random.randint(100000,999999)}
    def refresh_market_data(self): self._lat()
    def get_tradable_params(self,p): self._lat(); return {'params':['notional']}
    def generate_termsheet(self,p): self._lat(); return b'%PDF-1.4 dummy'
