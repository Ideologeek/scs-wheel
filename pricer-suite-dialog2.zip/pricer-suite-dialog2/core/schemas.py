
import pathlib, re
TYPE={'double':'float','string':'str','bool':'bool','int32':'int','int64':'int'}
_cache={}
def load_schema(product):
    if product in _cache: return _cache[product]
    base=pathlib.Path(__file__).resolve().parent.parent/'proto'
    mapping={'Autocallable Decrement':base/'wealth'/'autocallable_decrement.proto',
             'Dispersion':base/'institutional'/'dispersion.proto'}
    path=mapping[product]
    fields=[]
    for line in path.read_text().splitlines():
        m=re.match(r'(\w+)\s+(\w+)\s*=\s*\d+;',line.strip())
        if m:
            ptype,name=m.groups()
            fields.append({'name':name,'type':TYPE.get(ptype,'str'),'required':len(fields)<3})
    _cache[product]={'fields':fields}
    return _cache[product]
