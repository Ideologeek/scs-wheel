
import streamlit as st, pandas as pd
from core.analytics import backtest
st.title('Backtest')
pid=st.session_state.get('backtest_target')
if not pid: st.warning('No target'); st.stop()
pr=[p for p in st.session_state.pricers if p.id==pid]
if not pr: st.error('Missing'); st.stop()
p=pr[0]
st.subheader(f'{p.product} {p.id}')
df=backtest(p)
st.line_chart(df.set_index('date')['pnl'])
st.dataframe(df)
