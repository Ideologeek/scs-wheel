
import streamlit as st, pandas as pd, numpy as np
st.title('Market Data')
st.line_chart(pd.DataFrame(np.random.randn(100,3),columns=list('ABC')))
