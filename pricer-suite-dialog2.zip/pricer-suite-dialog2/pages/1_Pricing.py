
import streamlit as st
from core.ui import ribbon, pricer_container, add_pricer_dialog
if 'pricers' not in st.session_state: st.session_state.pricers=[]
st.title('Pricing Workbench')
ribbon()
if st.button('Add Pricer'): add_pricer_dialog()
for p in st.session_state.pricers: pricer_container(p)
