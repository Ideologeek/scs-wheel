"""
Demonstrates pricing a single autocall under Heston and Local Vol engines.
"""
import numpy as np
from aci.market import MarketSnapshot, Curve, FXQuantoSpec
from aci.surfaces import ImpliedVolSurface, DupireLocalVol
from aci.models.heston import HestonMCModel, HestonParams
from aci.models.lv import LocalVolMC
from aci.products.autocall import AutocallSpec, AutocallableIndexOption

def main():
    # Market curves and quanto
    S0 = 5000.0
    r = Curve([0,1,5,10],[0.02,0.02,0.02,0.02])
    q = Curve([0,1,5,10],[0.015,0.015,0.015,0.015])
    fx = FXQuantoSpec(quanto=False)  # quanto off for this demo
    mkt = MarketSnapshot(S0=S0, r_eur=r, q_div=q, fx_quanto=fx)

    # Product
    T_obs = [0.5, 1.0, 1.5, 2.0]
    B = [S0]*4
    C = [0.04*S0]*4
    spec = AutocallSpec(observation_times=T_obs, barriers=B, coupons=C, final_rule="unprotected")
    product = AutocallableIndexOption(spec)

    # Heston pricing
    hparams = HestonParams(v0=0.04, kappa=1.5, theta=0.04, xi=0.6, rho=-0.7)
    heston = HestonMCModel(mkt, hparams, n_paths=60_000, dt=1/252, seed=42)
    S_snaps = heston.simulate_snapshots(T_obs)
    pay = np.array([product.payoff_path(S_snaps[i,:], np.array(T_obs), S0) for i in range(S_snaps.shape[0])])
    df = np.exp(-r.r(T_obs[-1])*T_obs[-1])
    pv_heston = df * pay.mean()
    print(f"Heston PV: {pv_heston:.4f}")

    # Local-Vol (toy LV from flat surface)
    Ts = np.array([0.25, 0.5, 1.0, 2.0])
    Ks = np.linspace(3000, 7000, 9)
    vols = np.full((len(Ts), len(Ks)), 0.20)
    surface = ImpliedVolSurface(Ts, Ks, vols)
    def F(T): return S0*np.exp((r.r(T)-q.r(T))*T)
    def D(T): return np.exp(-r.r(T)*T)
    def qf(T): return q.r(T)
    def kappa(T): return r.r(T) - q.r(T)
    lv_grid = DupireLocalVol.from_surface(surface, F, D, qf, kappa)
    lv = LocalVolMC(S0, lv_grid, n_paths=60_000, dt=1/252, seed=7)
    mu = r.r(0.0) - q.r(0.0)
    S_lv = lv.simulate_snapshots(T_obs, mu=mu)
    pay_lv = np.array([product.payoff_path(S_lv[i,:], np.array(T_obs), S0) for i in range(S_lv.shape[0])])
    pv_lv = df * pay_lv.mean()
    print(f"Local-Vol PV: {pv_lv:.4f}")

if __name__ == "__main__":
    main()
