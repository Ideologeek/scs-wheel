import datetime as dt
from dataclasses import dataclass
from typing import List
import numpy as np
import pandas as pd

@dataclass
class DividendEvent:
    """Cash dividend per index unit on a calendar date (used to transform PR↔TR series)."""
    date: dt.date
    cash: float  # cash dividend per index unit

def effective_q(div_yield: float, return_type: str, withholding_rate: float = 0.0) -> float:
    """
    Map headline dividend yield to the effective convenience yield q_eff entering drift r - q_eff:
      - PR : q_eff = q
      - GTR: q_eff = 0
      - NTR: q_eff = w*q  (withholding w ∈ [0,1])
      - ER : q_eff = q   (but we typically zero-out ∫r dt in the drift)
    """
    rt = (return_type or "PR").upper()
    if rt == "PR":   return div_yield
    if rt == "GTR":  return 0.0
    if rt == "NTR":  return max(0.0, min(1.0, withholding_rate)) * div_yield
    if rt == "ER":   return div_yield
    raise ValueError(f"Unknown return_type '{return_type}'")

def build_tr_from_pr(pr_df: pd.DataFrame, dividends: List[DividendEvent], withholding_rate: float = 0.0) -> pd.DataFrame:
    """
    Given a Price Return series df(date, spot), build Gross TR and Net TR series.
    Returns df(date, pr, gtr, ntr).
    """
    df = pr_df.copy().sort_values("date").reset_index(drop=True)
    df["date"] = pd.to_datetime(df["date"]).dt.date
    df["pr"] = df["spot"].astype(float)
    df["gtr"] = df["pr"].values
    df["ntr"] = df["pr"].values
    div_map = {d.date: d.cash for d in dividends}
    g = df["gtr"].to_numpy().copy()
    n = df["ntr"].to_numpy().copy()
    for i in range(1, len(df)):
        d = df.at[i, "date"]
        cash = div_map.get(d, 0.0)
        if cash != 0.0:
            base = max(df.at[i-1, "pr"], 1e-12)
            g[i:] *= 1.0 + cash / base
            n[i:] *= 1.0 + cash * (1.0 - max(0.0, min(1.0, withholding_rate))) / base
    df["gtr"] = g; df["ntr"] = n
    return df[["date","pr","gtr","ntr"]]

def build_pr_from_tr(tr_df: pd.DataFrame, dividends: List[DividendEvent], withholding_rate: float = 0.0, assume="GTR") -> pd.DataFrame:
    """
    Given a TR series (GTR or NTR) and dividends, reconstruct the PR series.
    Returns df(date, pr).
    """
    df = tr_df.copy().sort_values("date").reset_index(drop=True)
    df["date"] = pd.to_datetime(df["date"]).dt.date
    col = "gtr" if assume.upper()=="GTR" else "ntr"
    if col not in df.columns:
        raise ValueError(f"Input TR df must have column '{col}'")
    tr = df[col].astype(float).to_numpy()
    pr = tr.copy()
    div_map = {d.date: d.cash for d in dividends}
    for i in range(1, len(df)):
        d = df.at[i, "date"]
        cash = div_map.get(d, 0.0)
        if cash != 0.0:
            base = max(pr[i-1], 1e-12)
            factor = 1.0 + (cash / base) if assume.upper()=="GTR" else 1.0 + cash*(1.0-max(0.0,min(1.0,withholding_rate)))/base
            pr[i:] /= factor
    df["pr"] = pr
    return df[["date","pr"]]
