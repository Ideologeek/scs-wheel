from dataclasses import dataclass
from typing import List
import numpy as np

@dataclass
class AutocallSpec:
    """
    Generic autocall payoff spec for unit-underlying (index points).
    - observation_times: times in years to observation/call dates
    - barriers: absolute barrier levels at obs times (same units as S)
    - coupons: cash coupons paid on call (index points)
    - final_rule: "unprotected" or "soft_protected"
    - final_barrier: soft-protection threshold as multiple of S0 (if used)
    - decrement_flag/rate: deterministic decrement on mapped underlying (optional)
    """
    observation_times: List[float]
    barriers: List[float]
    coupons: List[float]
    final_rule: str = "unprotected"
    final_barrier: float = 0.6
    decrement_flag: bool = False
    decrement_rate: float = 0.0
    reset_on_call: bool = True

class AutocallableIndexOption:
    """Pathwise payoff calculator for the spec above."""
    def __init__(self, spec: AutocallSpec):
        assert len(spec.observation_times) == len(spec.barriers) == len(spec.coupons)
        self.spec = spec

    def mapped_level(self, S: float, t: float) -> float:
        if not self.spec.decrement_flag:
            return S
        return S - self.spec.decrement_rate * t

    def payoff_path(self, S_obs: np.ndarray, t_obs: np.ndarray, S0: float) -> float:
        cash = 0.0
        for k, (Sk, tk) in enumerate(zip(S_obs, t_obs)):
            mapped = self.mapped_level(Sk, tk)
            if mapped >= self.spec.barriers[k]:
                cash += self.spec.coupons[k]
                return cash
        # Not called: final rule
        mapped_T = self.mapped_level(S_obs[-1], t_obs[-1])
        if self.spec.final_rule == "unprotected":
            return cash + mapped_T
        else:
            thresh = self.spec.final_barrier * S0
            return cash + (S0 if mapped_T >= thresh else mapped_T)
