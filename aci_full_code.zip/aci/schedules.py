import datetime as dt
import calendar as cal
from typing import List, Optional, Tuple

DAY_COUNT = 365.0

def yearfrac(d0: dt.date, d1: dt.date) -> float:
    return max(0.0, (d1 - d0).days / DAY_COUNT)

def _safe_add_years(d: dt.date, years: int) -> dt.date:
    y, m, day = d.year + years, d.month, d.day
    while True:
        try:
            return dt.date(y, m, day)
        except ValueError:
            day -= 1

def add_months_unadjusted(d: dt.date, k: int) -> dt.date:
    y = d.year + (d.month - 1 + k) // 12
    m = (d.month - 1 + k) % 12 + 1
    day = min(d.day, cal.monthrange(y, m)[1])
    return dt.date(y, m, day)

class SpotCalendar:
    """Calendar from trading dates; provides date<->index helpers and 'following' roll."""
    def __init__(self, trading_dates: List[dt.date]):
        self.dts = sorted(trading_dates)
        self.n = len(self.dts)
        self.idx_by_date = {d:i for i,d in enumerate(self.dts)}

    def index_of(self, d: dt.date) -> int:
        return self.idx_by_date.get(d, self.following_index(d))

    def following_index(self, d: dt.date) -> int:
        lo, hi = 0, self.n
        while lo < hi:
            mid = (lo + hi) // 2
            if self.dts[mid] < d: lo = mid + 1
            else: hi = mid
        return min(lo, self.n-1)

    def date_at(self, i: int) -> dt.date:
        return self.dts[min(max(i,0), self.n-1)]

def following_trading_day(d: dt.date, cal: SpotCalendar) -> dt.date:
    return cal.date_at(cal.following_index(d))

def build_note_schedule_monthly_lastcall(
    issue_idx: int, cal: SpotCalendar,
    tenor_years: float, ncp_years: float,
    include_call_at_ncp: bool = True
):
    """
    Monthly coupons, monthly calls from the NCP anchor (inclusive option),
    maturity = last call date.
    """
    issue_date = cal.date_at(issue_idx)
    K_total = int(round(12 * tenor_years))
    K_ncp   = int(round(12 * ncp_years))

    coupons: List[dt.date] = []
    for k in range(1, K_total + 1):
        cand  = add_months_unadjusted(issue_date, k)
        coupons.append(following_trading_day(cand, cal))

    maturity = coupons[-1]
    ncp_anchor = following_trading_day(add_months_unadjusted(issue_date, K_ncp), cal)
    if include_call_at_ncp:
        calls = [d for d in coupons if d >= ncp_anchor]
    else:
        calls = [d for d in coupons if d >  ncp_anchor]
    first_call = calls[0] if calls else None
    return coupons, calls, maturity, first_call
