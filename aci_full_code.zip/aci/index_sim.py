"""
Daily index simulator:
- Weekly issuance of identical-terms notes (calendar-monthly, maturity=last call)
- Par-coupon at issue computed by MC on call/coupon grid (consistent with sleeve PV kernel)
- Sleeve MTM PV decomposition: coupon / early-call principal / maturity principal / down-in put
- Cash management with both TR and PR ledgers:
    TR: accrues at OIS between trading days
    PR: non-accruing (standard price-return convention for published PR tracks)
Outputs:
  - index_level_all.csv (date, level_tr, level_pr)
  - index_level_components.csv (cash_tr, cash_pr, sleeve splits, live count)
"""
import math, datetime as dt
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple, Optional
import numpy as np
import pandas as pd

from .schedules import SpotCalendar, yearfrac, build_note_schedule_monthly_lastcall
from .market import Curve
from .valuation import ValuationFactory, sleeve_pv_from_paths, _drift_exponent

@dataclass
class IndexConfig:
    # Scheduling / issuance
    tenor_years: float = 5.0
    non_call_years: float = 1.0
    issue_every_days: int = 7
    l_target: int = 52
    cap_per_note: float = 0.05
    # Barriers / coupons
    call_trigger_mult: float = 1.0
    coupon_barrier_mult: float = 0.60
    principal_barrier_mult: float = 0.60
    coupon_on_call: bool = True
    # Market dynamics and underlier conventions
    sigma: float = 0.20
    risk_free: float = 0.03          # OIS flat stub (use your curve bootstrap)
    div_yield: float = 0.012         # headline dividend yield (or curve proxy)
    decrement: float = 0.00          # deterministic decrement (acts like extra q)
    underlying_return_type: str = 'PR'   # 'PR'|'GTR'|'NTR'|'ER'
    withholding_rate: float = 0.0        # for NTR
    # Valuation smoothing (valuation-only; realized barriers remain hard)
    shift_log_call: float = 0.0
    shift_log_cpn: float = 0.0
    shift_log_put: float = 0.0
    # Cash / financing
    initial_index: float = 100.0
    no_borrow: bool = True
    produce_price_return: bool = True
    # Engines
    mc_paths: int = 100_000
    seed: int = 12345

# ---------- Par coupon (MC on call/coupon grid) ----------
def par_coupon_at_issue(
    issue_date: dt.date,
    coupon_dates: List[dt.date], call_dates: List[dt.date],
    curve: Curve,
    S0: float, sigma: float, q: float, f: float,
    call_mult: float, coupon_bar: float, principal_bar: float,
    shift_log_call: float, shift_log_cpn: float, shift_log_put: float,
    return_type: str, withholding: float,
    mc_paths: int, seed: int
) -> float:
    """Solve c such that PV(coupons) + PV(call/maturity) - PV(put) = 100 (per notional 100)."""
    if not call_dates:
        return 0.0
    rng = np.random.default_rng(seed)
    taus = np.array([yearfrac(issue_date, d) for d in call_dates], float)
    m = len(taus)
    cov = (sigma*sigma) * np.minimum.outer(taus, taus)
    L = np.linalg.cholesky(cov + 1e-12*np.eye(m))
    phi = np.array([_drift_exponent(curve, issue_date, u, t, q, f, return_type, withholding) for u,t in zip(call_dates, taus)], float)
    mu = np.log(S0) + (phi - 0.5*sigma*sigma)
    A_log = math.log(call_mult*S0) + shift_log_call
    I_log = math.log(coupon_bar*S0) + shift_log_cpn
    B_log = math.log(principal_bar*S0) + shift_log_put
    DF_call = np.array([math.exp(-curve.r(t)*t) for t in taus])
    Z = rng.standard_normal((mc_paths, m))
    X = mu + Z @ L.T

    # Call survival & call probabilities
    alive = np.ones(mc_paths, dtype=bool)
    qj = np.zeros(m)
    p_alive = np.zeros(m)
    for j in range(m):
        p_alive[j] = np.mean(alive)
        hit = X[:, j] >= A_log  # call if logS >= A_log
        qj[j] = np.mean(alive & hit)
        alive &= ~hit

    # Coupon annuity
    first_call = call_dates[0]; call_index = {d:j for j,d in enumerate(call_dates)}
    A_sum = 0.0
    for u in coupon_dates:
        DFu = math.exp(-curve.r(yearfrac(issue_date,u))*yearfrac(issue_date,u))
        if u < first_call:
            t = yearfrac(issue_date, u)
            mu1 = math.log(S0) + (_drift_exponent(curve, issue_date, u, t, q, f, return_type, withholding) - 0.5*sigma*sigma)
            std1 = sigma*math.sqrt(t)
            z = (math.log(coupon_bar*S0) + shift_log_cpn - mu1)/max(std1,1e-16)
            # P(logS >= log I) = 1 - Phi(z)
            pi = 1.0 - 0.5*(1.0 + math.erf(z/math.sqrt(2)))
            A_sum += DFu * pi
        else:
            j = call_index[u]
            alive_to_j = np.ones(mc_paths, dtype=bool)
            for k in range(j):
                alive_to_j &= (X[:, k] < A_log)  # no earlier call
            pi = np.mean(alive_to_j & (X[:, j] >= I_log))
            A_sum += DFu * pi

    V_call = float(np.sum(100.0 * DF_call * qj))
    V_mat  = float(100.0 * DF_call[-1] * p_alive[-1])

    # Down-in put at maturity, conditional on survival to m-1 (proxy)
    alive_m1 = np.ones(mc_paths, dtype=bool)
    for k in range(m-1): alive_m1 &= (X[:, k] < A_log)
    at_B = X[:, -1] <= B_log
    P_lt = float(np.mean(alive_m1 & at_B))
    M_lt = float(np.mean(np.exp(X[:, -1]) * (alive_m1 & at_B)))
    DF_T = float(DF_call[-1])
    V_put = DF_T * ((100.0/S0) * (S0*P_lt - M_lt))

    base = V_call + V_mat - V_put
    PV_TARGET = 100.0
    if A_sum <= 1e-12:
        return 0.0 if base >= PV_TARGET else 0.20
    c_star = (PV_TARGET - base) / (100.0 * A_sum)
    return max(0.0, float(c_star))

# ---------- Group PV (using ValuationFactory engine) ----------
def pv_group(
    today: dt.date, S_today: float,
    notes: List[Dict[str, Any]],
    call_dates: List[dt.date],
    curve: Curve,
    cfg: IndexConfig,
    val_factory: Optional[ValuationFactory] = None
) -> Tuple[float,float,float,float,float]:
    if (len(notes)==0) or (len(call_dates)==0):
        return (0.0,0.0,0.0,0.0,0.0)

    # Union grid = future call dates ∪ pending coupon dates (per sleeve)
    coupon_union = sorted({d for n in notes for d in n['coupon_dates'] if d > today})
    grid_dates = sorted(set(call_dates).union(set(coupon_union)))

    if val_factory is None:
        val_factory = ValuationFactory(model='logn', paths=cfg.mc_paths, seed=cfg.seed, sigma=cfg.sigma)
    engine = val_factory.build()

    S_paths = engine.simulate(
        today, S_today, grid_dates, curve,
        div_yield=cfg.div_yield, decrement=cfg.decrement,
        return_type=cfg.underlying_return_type, withholding=cfg.withholding_rate
    )

    return sleeve_pv_from_paths(today, S_today, notes, call_dates, grid_dates, S_paths, curve)

# ---------- Daily simulator ----------
def simulate_index(
    spot_csv: str, out_level_csv: str, out_components_csv: str, cfg: IndexConfig,
    val_factory: Optional[ValuationFactory]=None
) -> None:
    df = pd.read_csv(spot_csv, parse_dates=['date']).set_index('date').sort_index()
    dates = [d.date() for d in df.index.to_list()]
    spots = df['spot'].to_numpy(float)
    cal = SpotCalendar(dates)
    curve = Curve([0.0, 1.0, 30.0], [cfg.risk_free]*3)

    # Two ledgers: TR accrues, PR does not.
    cash_tr = float(cfg.initial_index)
    cash_pr = float(cfg.initial_index)
    portfolio: List[Dict[str, Any]] = []
    last_issue: Optional[dt.date] = None

    levels, comps = [], []

    for t_idx, (t_date, S_today) in enumerate(zip(dates, spots), start=1):
        # Realized flows for live notes
        still_live: List[Dict[str, Any]] = []
        for pos in portfolio:
            N_i = pos['notional']; S0_i = pos['S0']
            # Coupons
            while pos['ci'] < len(pos['coupon_dates']) and pos['coupon_dates'][pos['ci']] == t_date:
                if S_today >= cfg.coupon_barrier_mult * S0_i:
                    inc = N_i * pos['coupon_rate']
                    cash_tr += inc; cash_pr += inc
                pos['ci'] += 1
            # Call/maturity (last call = maturity)
            called = False
            if pos['ki'] < len(pos['call_dates']) and pos['call_dates'][pos['ki']] == t_date:
                if S_today >= cfg.call_trigger_mult * S0_i:
                    cash_tr += N_i; cash_pr += N_i; called = True
                pos['ki'] += 1
            if (not called) and t_date > pos['call_dates'][-1]:
                if S_today >= cfg.principal_barrier_mult * S0_i:
                    cash_tr += N_i; cash_pr += N_i
                else:
                    amt = N_i * (S_today / S0_i)
                    cash_tr += amt; cash_pr += amt
                called = True
            if not called:
                still_live.append(pos)
        portfolio = still_live

        # Accrue TR cash to next day (PR cash does not accrue)
        if t_idx < len(dates):
            next_date = dates[t_idx]
            tau = yearfrac(t_date, next_date)
            cash_tr *= math.exp(cfg.risk_free * tau)

        # Group by shared future call grid
        def _group_key(pos: Dict[str, Any]):
            fut_calls = tuple(d for d in pos['call_dates'] if d > t_date)
            key_calls = tuple(cal.index_of(d) for d in fut_calls)
            return (key_calls, round(cfg.sigma,6), round(cfg.div_yield,6), round(cfg.decrement,6),
                    round(cfg.call_trigger_mult,6), round(cfg.coupon_barrier_mult,6), round(cfg.principal_barrier_mult,6))

        groups: Dict[Tuple, List[int]] = {}
        for i, pos in enumerate(portfolio):
            groups.setdefault(_group_key(pos), []).append(i)

        sleeve_total = sleeve_coupon = sleeve_call = sleeve_mat = sleeve_put = 0.0
        for key, idxs in groups.items():
            call_idx_tuple = key[0]
            if len(call_idx_tuple) == 0: 
                continue
            fut_call_dates = [cal.date_at(i) for i in call_idx_tuple]
            group_notes = [portfolio[i] for i in idxs]
            res = pv_group(t_date, S_today, group_notes, fut_call_dates, curve, cfg, val_factory)
            sleeve_total += res[0]; sleeve_coupon += res[1]; sleeve_call += res[2]; sleeve_mat += res[3]; sleeve_put += res[4]

        level_tr = cash_tr + sleeve_total
        level_pr = cash_pr + sleeve_total

        # Weekly issuance (up to one new note), ticket capped
        if (last_issue is None) or ((t_date - last_issue).days >= cfg.issue_every_days):
            last_issue = t_date
            issue_idx = cal.index_of(t_date)
            cpn_dates, cal_dates, mat_date, first_call = build_note_schedule_monthly_lastcall(
                issue_idx, cal, cfg.tenor_years, cfg.non_call_years, True
            )
            c_star = par_coupon_at_issue(
                t_date, cpn_dates, cal_dates, curve,
                S0=S_today, sigma=cfg.sigma, q=cfg.div_yield, f=cfg.decrement,
                call_mult=cfg.call_trigger_mult, coupon_bar=cfg.coupon_barrier_mult, principal_bar=cfg.principal_barrier_mult,
                shift_log_call=cfg.shift_log_call, shift_log_cpn=cfg.shift_log_cpn, shift_log_put=cfg.shift_log_put,
                return_type=cfg.underlying_return_type, withholding=cfg.withholding_rate,
                mc_paths=max(50_000, cfg.mc_paths//2), seed=cfg.seed
            )
            ticket = min(level_tr / max(cfg.l_target,1), cfg.cap_per_note * level_tr)
            need = max(0, cfg.l_target - len(portfolio))
            can_fund = int(cash_tr // max(ticket, 1e-9)) if cfg.no_borrow else 1
            n_new = min(1, need, can_fund)
            if n_new == 1 and ticket > 0.0:
                cash_tr -= ticket; cash_pr -= ticket
                portfolio.append({
                    'start': t_date,
                    'S0': float(S_today),
                    'notional': float(ticket),
                    'coupon_rate': float(c_star),
                    'coupon_dates': list(cpn_dates),
                    'call_dates': list(cal_dates),
                    'ci': 0, 'ki': 0,
                    # per-note cached knobs
                    'call_mult': cfg.call_trigger_mult,
                    'coupon_bar': cfg.coupon_barrier_mult,
                    'principal_bar': cfg.principal_barrier_mult,
                    'shift_log_call': cfg.shift_log_call,
                    'shift_log_cpn': cfg.shift_log_cpn,
                    'shift_log_put': cfg.shift_log_put,
                })

        levels.append({'date': t_date.isoformat(), 'level_tr': level_tr, 'level_pr': level_pr})
        comps.append({
            'date': t_date.isoformat(),
            'cash_tr': cash_tr, 'cash_pr': cash_pr,
            'sleeve_pv_total': sleeve_total,
            'sleeve_pv_coupon': sleeve_coupon,
            'sleeve_pv_call_principal': sleeve_call,
            'sleeve_pv_maturity_principal': sleeve_mat,
            'sleeve_pv_put_down_in': sleeve_put,
            'nlive': len(portfolio),
            'avg_coupon_live': (sum(n['coupon_rate']*n['notional'] for n in portfolio)/max(1.0,sum(n['notional'] for n in portfolio))) if portfolio else 0.0
        })

    pd.DataFrame(levels).to_csv(out_level_csv, index=False)
    pd.DataFrame(comps).to_csv(out_components_csv, index=False)
