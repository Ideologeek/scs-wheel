from dataclasses import dataclass
import numpy as np
import math
from typing import Callable

def norm_cdf(x: float) -> float:
    return 0.5*(1.0+math.erf(x/math.sqrt(2.0)))

def bs_call_price_forward(F: float, K: float, T: float, vol: float) -> float:
    """
    Undiscounted forward call price C = E[(S_T - K)^+] under forward measure.
    """
    if T <= 0:
        return max(F-K, 0.0)
    vol = max(vol, 1e-12)
    s = vol*math.sqrt(T)
    if s < 1e-12:
        return max(F-K, 0.0)
    d1 = (math.log(F/K)+0.5*s*s)/s
    d2 = d1 - s
    return F*norm_cdf(d1) - K*norm_cdf(d2)

@dataclass
class ImpliedVolSurface:
    """Bilinear-interpolated implied vol surface on (T, K)."""
    maturities: np.ndarray     # shape (M,)
    strikes: np.ndarray        # shape (K,)
    vols: np.ndarray           # shape (M,K)

    def vol(self, T: float, K: float) -> float:
        Ts, Ks = self.maturities, self.strikes
        T = float(np.clip(T, Ts[0], Ts[-1]))
        K = float(np.clip(K, Ks[0], Ks[-1]))
        i = min(max(1, np.searchsorted(Ts, T)), len(Ts)-1)
        j = min(max(1, np.searchsorted(Ks, K)), len(Ks)-1)
        T0, T1 = Ts[i-1], Ts[i]; K0, K1 = Ks[j-1], Ks[j]
        wT = 0.0 if T1==T0 else (T - T0)/(T1 - T0)
        wK = 0.0 if K1==K0 else (K - K0)/(K1 - K0)
        v00 = self.vols[i-1, j-1]; v01 = self.vols[i-1, j]
        v10 = self.vols[i, j-1];   v11 = self.vols[i, j]
        v0 = v00*(1-wK)+v01*wK
        v1 = v10*(1-wK)+v11*wK
        return v0*(1-wT)+v1*wT

@dataclass
class DupireLocalVol:
    """
    Dupire local volatility grid σ_LV(T, K). Provide by calibration (eSSVI→Dupire),
    or build via the helper below for toy surfaces.
    """
    maturities: np.ndarray
    strikes: np.ndarray
    lv: np.ndarray   # shape (M, K)

    @staticmethod
    def from_surface(surface: ImpliedVolSurface, F_fn: Callable[[float], float],
                     disc_fn: Callable[[float], float], q_fn: Callable[[float], float],
                     kappa_fn: Callable[[float], float]) -> 'DupireLocalVol':
        """
        Crude Dupire extractor for demonstration:
        σ_LV^2 = (∂_T C + κ K ∂_K C + q C) / (0.5 K^2 ∂_{KK} C), with C forward undiscounted.
        NOTE: For production, replace with your arbitrage-free eSSVI fit + Dupire with
        proper smoothing and stable greeks.
        """
        Ts = surface.maturities; Ks = surface.strikes
        M, KN = len(Ts), len(Ks)
        grid = np.zeros((M, KN))
        epsT = 1e-4
        for i, T in enumerate(Ts):
            F = F_fn(T); D = disc_fn(T); q = q_fn(T); kappa = kappa_fn(T)
            for j, K in enumerate(Ks):
                vol = surface.vol(T, K)
                C = bs_call_price_forward(F, K, T, vol)
                dK = 1e-4*max(1.0, K)
                Cp = bs_call_price_forward(F, K+dK, T, surface.vol(T, K+dK))
                Cm = bs_call_price_forward(F, K-dK, T, surface.vol(T, K-dK))
                C_K  = (Cp - Cm)/(2*dK)
                C_KK = max((Cp - 2*C + Cm)/(dK*dK), 1e-12)
                dT = max(epsT, Ts[min(i+1,M-1)]-Ts[max(i-1,0)])*0.5
                Ct = bs_call_price_forward(F, K, T+dT, surface.vol(T+dT, K))
                C_T = (Ct - C)/dT
                denom = 0.5*(K**2)*C_KK
                num = C_T + kappa*K*C_K + q*C
                sigma2 = max(num/denom, 1e-8)
                grid[i, j] = math.sqrt(sigma2)
        return DupireLocalVol(Ts, Ks, grid)
