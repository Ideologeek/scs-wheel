import numpy as np, math
from ..surfaces import DupireLocalVol

class LocalVolMC:
    """
    Local Vol Monte Carlo with bilinear interpolation σ_LV(t,S) on a Dupire grid.
    Euler in log-space; pass drift μ explicitly (see valuation engine for μ).
    """
    def __init__(self, S0: float, lv_grid: DupireLocalVol, n_paths: int=100_000, dt: float=1/252, seed: int=12345):
        self.S0 = float(S0)
        self.lv = lv_grid
        self.n_paths = int(n_paths)
        self.dt = float(dt)
        self.rng = np.random.default_rng(seed)

    def _sigma(self, t, S):
        Ts = self.lv.maturities; Ks = self.lv.strikes; LV = self.lv.lv
        t = float(np.clip(t, Ts[0], Ts[-1]))
        S = float(np.clip(S, Ks[0], Ks[-1]))
        i = min(max(1, np.searchsorted(Ts, t)), len(Ts)-1)
        j = min(max(1, np.searchsorted(Ks, S)), len(Ks)-1)
        T0, T1 = Ts[i-1], Ts[i]; K0, K1 = Ks[j-1], Ks[j]
        wT = 0.0 if T1==T0 else (t-T0)/(T1-T0)
        wK = 0.0 if K1==K0 else (S-K0)/(K1-K0)
        v00 = LV[i-1, j-1]; v01 = LV[i-1, j]; v10 = LV[i, j-1]; v11 = LV[i, j]
        v0 = v00*(1-wK)+v01*wK; v1 = v10*(1-wK)+v11*wK
        return v0*(1-wT)+v1*wT

    def simulate_snapshots(self, obs_times, mu: float=0.0):
        S = np.full(self.n_paths, self.S0, float)
        out = []
        t_prev = 0.0
        for t_obs in sorted(obs_times):
            n_steps = max(1, int((t_obs - t_prev)/self.dt))
            for step in range(n_steps):
                t = t_prev + (step+0.5)*((t_obs - t_prev)/n_steps)
                sig = np.array([self._sigma(t, s) for s in S])
                Z = self.rng.standard_normal(self.n_paths)
                dt = (t_obs - t_prev)/n_steps
                S *= np.exp((mu - 0.5*sig*sig)*dt + sig*np.sqrt(dt)*Z)
            out.append(S.copy())
            t_prev = t_obs
        return np.column_stack(out)
