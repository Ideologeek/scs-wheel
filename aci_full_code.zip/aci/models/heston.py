from dataclasses import dataclass
import numpy as np, math
from ..market import MarketSnapshot

@dataclass
class HestonParams:
    """Standard Heston parameters."""
    v0: float
    kappa: float
    theta: float
    xi: float
    rho: float

class HestonMCModel:
    """
    Heston Monte Carlo using Andersen QE for variance and log-Euler for spot.
    Drift is provided via MarketSnapshot.r_eur (r) and q_div (q).
    """
    def __init__(self, market: MarketSnapshot, params: HestonParams, n_paths: int=100_000, dt: float=1/252, seed: int=12345):
        self.mkt = market
        self.p = params
        self.n_paths = int(n_paths)
        self.dt = float(dt)
        self.rng = np.random.default_rng(seed)

    def simulate_snapshots(self, obs_times):
        """
        Simulate S at given observation times (year fractions). Returns array (n_paths, len(obs_times)).
        """
        obs_times = sorted(obs_times)
        S = np.full(self.n_paths, self.mkt.S0, float)
        v = np.full(self.n_paths, self.p.v0, float)
        out = []
        t_prev = 0.0
        for t_obs in obs_times:
            n_steps = max(1, int((t_obs - t_prev)/self.dt))
            for _ in range(n_steps):
                z1 = self.rng.standard_normal(self.n_paths)
                z2 = self.rng.standard_normal(self.n_paths)
                Ws = self.p.rho*z1 + math.sqrt(max(1e-12,1-self.p.rho*self.p.rho))*z2
                dt = (t_obs - t_prev)/n_steps
                # Andersen QE for v
                m  = self.p.theta + (v - self.p.theta)*math.exp(-self.p.kappa*dt)
                s2 = (v*self.p.xi*self.p.xi*math.exp(-self.p.kappa*dt)/self.p.kappa)*(1-math.exp(-self.p.kappa*dt)) \
                   + self.p.theta*self.p.xi*self.p.xi/(2*self.p.kappa)*(1-math.exp(-self.p.kappa*dt))**2
                psi = s2/((m*m)+1e-14)
                v_new = np.empty_like(v)
                idx = psi <= 1.5
                if np.any(idx):
                    b2 = 2/psi[idx] - 1 + np.sqrt(2/psi[idx]) * np.sqrt(2/psi[idx] - 1)
                    a  = m[idx]/(1+b2)
                    v_new[idx] = a*(np.sqrt(b2)*z1[idx] + 1)**2
                if np.any(~idx):
                    p = (psi[~idx]-1)/(psi[~idx]+1)
                    beta = (1-p)/m[~idx]
                    U = 0.5*(1+np.erf(z1[~idx]/np.sqrt(2)))
                    v_new[~idx] = np.where(U<=p, 0.0, -np.log((1-p)/(1-U))/beta)
                v_new = np.clip(v_new, 1e-12, None)
                mu = self.mkt.r_eur.r(0.0) - self.mkt.q_div.r(0.0)
                S *= np.exp((mu - 0.5*v)*dt + np.sqrt(v)*np.sqrt(dt)*Ws)
                v = v_new
            out.append(S.copy())
            t_prev = t_obs
        return np.column_stack(out)
