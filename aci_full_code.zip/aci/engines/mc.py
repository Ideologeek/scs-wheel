from dataclasses import dataclass
import numpy as np

@dataclass
class MCConfig:
    n_paths: int = 100_000
    seed: int = 12345

class CPU_GaussianMC:
    """Simple normal RNG wrapper with deterministic seed."""
    def __init__(self, cfg: MCConfig):
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)
    def gaussian(self, shape):
        return self.rng.standard_normal(shape)
