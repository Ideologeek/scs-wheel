# Optional Sobol QMC on Torch. Safe to import-guard when torch isn't installed.
from dataclasses import dataclass
import math

try:
    import torch
    from torch.quasirandom import SobolEngine
    TORCH_OK = True
except Exception:
    TORCH_OK = False
    torch = None

@dataclass
class QMCConfig:
    n_samples: int = 65536
    seed: int = 12345
    device: str = "cuda"

class TorchSobolNormals:
    """Global Sobol table → inverse CDF to N(0,1); reuse slices by dim."""
    def __init__(self, dim_max: int, cfg: QMCConfig):
        if not TORCH_OK:
            raise RuntimeError("PyTorch not available")
        dev = cfg.device if (cfg.device in ("cuda","cpu")) else "cpu"
        self.device = dev if (dev=="cpu" or torch.cuda.is_available()) else "cpu"
        self.dtype = torch.float64
        sob = SobolEngine(dim_max, scramble=True, seed=cfg.seed)
        U = sob.draw(cfg.n_samples).to(self.device)
        self.Z = math.sqrt(2.0) * torch.erfinv(2.0*U - 1.0)
        self.dim_max = dim_max
    def normals(self, d: int):
        return self.Z[:, :d].to(self.dtype)

def chol_psd(R, jitter_start=1e-12, max_tries=6):
    """Robust Cholesky with PSD fix/jitter for near-singular correlation."""
    R = 0.5*(R+R.T)
    I = torch.eye(R.shape[0], dtype=R.dtype, device=R.device)
    jitter = 0.0
    for k in range(max_tries):
        try:
            return torch.linalg.cholesky(R + jitter*I)
        except RuntimeError:
            jitter = max(jitter_start, 10.0**(-12+k))
    # fallback PSD fix
    w, V = torch.linalg.eigh(R)
    w = torch.clamp(w, min=1e-12)
    R_psd = (V * w) @ V.T
    d = torch.sqrt(torch.diag(R_psd))
    R_psd = R_psd / (d[:,None]*d[None,:])
    return torch.linalg.cholesky(R_psd + 1e-12*I)
