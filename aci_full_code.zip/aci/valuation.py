import math, datetime as dt
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple, Optional
import numpy as np

from .schedules import yearfrac
from .market import Curve, MarketSnapshot, FXQuantoSpec
from .models.heston import HestonMCModel, HestonParams
from .models.lv import LocalVolMC
from .surfaces import DupireLocalVol
from .underlying import effective_q

# ---------- Drift helper (single source of truth) ----------
def _drift_exponent(curve: Curve, d0: dt.date, d1: dt.date, tau: float,
                    q: float, f: float, return_type: str='PR', withholding: float=0.0) -> float:
    """
    Return the exponent term appearing in E[log S_T] under the chosen underlier return type:
      μ_int = ∫ r dt   (set to 0 if return_type == 'ER')
      q_eff = effective_q(q, return_type, withholding)
      drift exponent over [0,T]: μ_int - (q_eff + f) * T
    """
    rint = 0.0 if (return_type or "").upper() == 'ER' else curve.r(tau)*tau
    q_eff = effective_q(q, return_type, withholding)
    return rint - (q_eff + f) * tau

# ---------- Engine base ----------
class ValuationEngine:
    def simulate(self, today: dt.date, S_today: float, grid_dates: List[dt.date],
                 curve: Curve, *, div_yield: float, decrement: float,
                 return_type: str, withholding: float) -> np.ndarray:
        """
        Simulate S on grid_dates (sorted) and return array shape (paths, M). Implemented in subclasses.
        """
        raise NotImplementedError

# ---------- Lognormal engine ----------
class LognormalEngine(ValuationEngine):
    def __init__(self, paths: int, seed: int, sigma: float):
        self.paths = int(paths)
        self.seed = int(seed)
        self.sigma = float(sigma)

    def simulate(self, today, S_today, grid_dates, curve, *, div_yield, decrement, return_type, withholding):
        tau = np.array([yearfrac(today, d) for d in grid_dates], float)
        m = len(tau)
        cov = (self.sigma*self.sigma) * np.minimum.outer(tau, tau)
        L = np.linalg.cholesky(cov + 1e-12*np.eye(m))
        phi = np.array([
            _drift_exponent(curve, today, u, t, div_yield, decrement, return_type, withholding)
            for u,t in zip(grid_dates, tau)
        ], float)
        mu = math.log(S_today) + (phi - 0.5*self.sigma*self.sigma)
        rng = np.random.default_rng(self.seed)
        Z = rng.standard_normal((self.paths, m))
        X = mu + Z @ L.T
        return np.exp(X)

# ---------- Heston engine ----------
class HestonEngine(ValuationEngine):
    def __init__(self, params: HestonParams, paths: int, dt_step: float, seed: int):
        self.params = params
        self.paths = int(paths)
        self.dt_step = float(dt_step)
        self.seed = int(seed)

    def simulate(self, today, S_today, grid_dates, curve, *, div_yield, decrement, return_type, withholding):
        q_eff = effective_q(div_yield, return_type, withholding)
        r_curve = curve
        q_curve = Curve([0.0, 1.0, 30.0], [q_eff]*3)
        mkt = MarketSnapshot(S0=S_today, r_eur=r_curve, q_div=q_curve, fx_quanto=FXQuantoSpec(False,0.0,0.0))
        t_obs = [yearfrac(today, d) for d in grid_dates]
        model = HestonMCModel(mkt, self.params, n_paths=self.paths, dt=self.dt_step, seed=self.seed)
        return model.simulate_snapshots(t_obs)

# ---------- Local Vol engine ----------
class LocalVolEngine(ValuationEngine):
    def __init__(self, lv_grid: DupireLocalVol, paths: int, dt_step: float, seed: int):
        self.lv = lv_grid
        self.paths = int(paths)
        self.dt_step = float(dt_step)
        self.seed = int(seed)

    def simulate(self, today, S_today, grid_dates, curve, *, div_yield, decrement, return_type, withholding):
        q_eff = effective_q(div_yield, return_type, withholding)
        mu = (0.0 if (return_type or '').upper()=='ER' else curve.r(0.0)) - (q_eff + decrement)
        t_obs = [yearfrac(today, d) for d in grid_dates]
        model = LocalVolMC(S_today, self.lv, n_paths=self.paths, dt=self.dt_step, seed=self.seed)
        return model.simulate_snapshots(t_obs, mu=mu)

# ---------- Sleeve PV from simulated paths ----------
def sleeve_pv_from_paths(today: dt.date, S_today: float,
                         notes: List[Dict[str, Any]],
                         call_dates: List[dt.date],
                         grid_dates: List[dt.date],
                         S_paths: np.ndarray,
                         curve: Curve) -> Tuple[float,float,float,float,float]:
    """
    Compute sleeve PV decomposition using pathwise cashflows on the union grid.
    Returns (total, coupon, call_principal, maturity_principal, put_down_in).
    Coupon-on-call convention: coupon condition checked at the call date before principal.
    """
    if len(notes)==0 or len(call_dates)==0:
        return (0.0,0.0,0.0,0.0,0.0)

    idx = {d:i for i,d in enumerate(grid_dates)}
    paths, m = S_paths.shape

    def DF(d):
        t = yearfrac(today, d)
        return math.exp(-curve.r(t)*t)

    total = coupon_pv = call_pv = mat_pv = put_pv = 0.0
    X_all = np.log(S_paths + 1e-300)

    for n in notes:
        S0 = float(n['S0']); N = float(n['notional']); c_rate = float(n['coupon_rate'])
        A_log = math.log(n['call_mult'] * S0) + n['shift_log_call']
        I_log = math.log(n['coupon_bar'] * S0) + n['shift_log_cpn']
        B_log = math.log(n['principal_bar'] * S0) + n['shift_log_put']

        cf_coupon = np.zeros(paths)
        cf_call   = np.zeros(paths)
        called    = np.zeros(paths, dtype=bool)

        cpn_set = [d for d in n['coupon_dates'] if d > today]
        DF_cpn = {d: DF(d) for d in cpn_set}
        DF_call = {d: DF(d) for d in call_dates}
        DF_T = DF(call_dates[-1])

        for d in grid_dates:
            j = idx[d]
            xj = X_all[:, j]
            if d in DF_cpn:
                pay_coupon = (~called) & (xj >= I_log)
                cf_coupon += (N * c_rate * DF_cpn[d]) * pay_coupon.astype(float)
            if d in DF_call:
                pay_call = (~called) & (xj >= A_log)
                cf_call += (N * DF_call[d]) * pay_call.astype(float)
                called |= pay_call

        alive_T = ~called
        xT = X_all[:, idx[call_dates[-1]]]
        ST = np.exp(xT)
        mat_amount = np.where(ST >= math.exp(B_log), N, N * (ST / S0))
        cf_mat = DF_T * alive_T.astype(float) * mat_amount
        put_amount = np.where(ST < math.exp(B_log), (N - N*(ST/S0)), 0.0)
        cf_put = DF_T * alive_T.astype(float) * put_amount

        note_coupon = float(cf_coupon.mean())
        note_call   = float(cf_call.mean())
        note_mat    = float(cf_mat.mean())
        note_put    = float(cf_put.mean())
        note_total  = note_coupon + note_call + note_mat

        coupon_pv += note_coupon; call_pv += note_call; mat_pv += note_mat; put_pv += note_put; total += note_total

    return total, coupon_pv, call_pv, mat_pv, put_pv

# ---------- Factory ----------
@dataclass
class ValuationFactory:
    """
    Unified way to create a pricing engine:

      model: 'logn' | 'heston' | 'lv'
      paths: Monte Carlo paths (per batch)
      seed: RNG seed
      sigma: lognormal vol (for 'logn')
      dt_step: time step (years) for Heston/LV
      heston_params: parameters when model='heston'
      lv_grid: DupireLocalVol grid when model='lv'
    """
    model: str = "logn"
    paths: int = 100_000
    seed: int = 12345
    sigma: float = 0.20
    dt_step: float = 1/252
    heston_params: Optional[HestonParams] = None
    lv_grid: Optional[DupireLocalVol] = None

    def build(self) -> ValuationEngine:
        if self.model == "logn":
            return LognormalEngine(self.paths, self.seed, self.sigma)
        elif self.model == "heston":
            if self.heston_params is None:
                raise ValueError("heston_params required for Heston engine")
            return HestonEngine(self.heston_params, self.paths, self.dt_step, self.seed)
        elif self.model == "lv":
            if self.lv_grid is None:
                raise ValueError("lv_grid required for LocalVol engine")
            return LocalVolEngine(self.lv_grid, self.paths, self.dt_step, self.seed)
        else:
            raise ValueError(f"unknown model '{self.model}'")
