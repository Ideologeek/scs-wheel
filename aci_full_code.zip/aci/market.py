from dataclasses import dataclass
import math
from typing import List

@dataclass
class Curve:
    """
    Simple continuously-compounded curve r(T) with linear interpolation on pillars (T in years).
    .r(T): instantaneous flat-at-maturity rate
    .df(T): discount factor exp(-r(T)*T)
    """
    pillars: List[float]  # ascending maturities (years)
    rates: List[float]    # continuous compounding rates

    def r(self, T: float) -> float:
        if T <= self.pillars[0]:
            return self.rates[0]
        if T >= self.pillars[-1]:
            return self.rates[-1]
        for i in range(1, len(self.pillars)):
            if T <= self.pillars[i]:
                w = (T - self.pillars[i-1])/(self.pillars[i]-self.pillars[i-1])
                return self.rates[i-1]*(1-w) + self.rates[i]*w
        return self.rates[-1]

    def df(self, T: float) -> float:
        return math.exp(-self.r(T)*T)

@dataclass
class FXQuantoSpec:
    """Quanto specification: whether pricing under a foreign (EUR) measure with FX correlation adjustments."""
    quanto: bool
    fx_vol: float = 0.0
    rho_s_fx: float = 0.0

@dataclass
class MarketSnapshot:
    """Convenience container for model engines (Heston)."""
    S0: float
    r_eur: Curve
    q_div: Curve
    fx_quanto: FXQuantoSpec
