"""
Minimal end-to-end demo:
- Loads (or generates) a PR spot series spot_data.csv with columns [date, spot]
- Runs the index simulator and writes:
    index_level_all.csv          (date, level_tr, level_pr)
    index_level_components.csv   (cash ledgers + sleeve PV splits)
Switch the valuation engine in the 'valf' line below.
"""
import os, math, csv, random, datetime as dt
import pandas as pd
from aci.index_sim import simulate_index, IndexConfig
from aci.valuation import ValuationFactory
from aci.models.heston import HestonParams

ROOT = os.path.dirname(__file__)
SPOT_CSV = os.path.join(ROOT, "spot_data.csv")
OUT_LEVEL = os.path.join(ROOT, "index_level_all.csv")
OUT_COMP  = os.path.join(ROOT, "index_level_components.csv")

def maybe_make_demo_spot(path: str, days: int = 252*3, S0: float = 100.0, r=0.03, q=0.012, sigma=0.20, seed=7):
    if os.path.exists(path): 
        return
    random.seed(seed)
    start = dt.date(2021,1,4)
    rows = []
    S = S0
    for i in range(days):
        d = start + dt.timedelta(days=i)
        if d.weekday() >= 5: 
            continue
        z = random.gauss(0.0, 1.0)
        S *= math.exp((r - q - 0.5*sigma*sigma)/252 + sigma/math.sqrt(252)*z)
        rows.append({"date": d.isoformat(), "spot": S})
    pd.DataFrame(rows).to_csv(path, index=False)
    print(f"[demo] wrote {path}")

def main():
    maybe_make_demo_spot(SPOT_CSV)
    cfg = IndexConfig(
        tenor_years=5.0, non_call_years=1.0, issue_every_days=7,
        l_target=52, cap_per_note=0.05,
        call_trigger_mult=1.0, coupon_barrier_mult=0.60, principal_barrier_mult=0.60,
        sigma=0.20, risk_free=0.03, div_yield=0.012, decrement=0.00,
        underlying_return_type='PR', withholding_rate=0.0,
        shift_log_call=0.0, shift_log_cpn=0.0, shift_log_put=0.0,
        initial_index=100.0, no_borrow=True,
        mc_paths=100_000, seed=12345
    )

    # Choose your valuation engine:
    valf = ValuationFactory(model='logn', paths=cfg.mc_paths, seed=cfg.seed, sigma=cfg.sigma)
    # Example Heston:
    # valf = ValuationFactory(model='heston', paths=cfg.mc_paths, seed=cfg.seed,
    #                         heston_params=HestonParams(v0=0.04,kappa=1.5,theta=0.04,xi=0.6,rho=-0.7))
    # Example Local-Vol: build a DupireLocalVol grid and pass lv_grid=...
    simulate_index(SPOT_CSV, OUT_LEVEL, OUT_COMP, cfg, valf)
    print(f"Wrote {OUT_LEVEL} and {OUT_COMP}")

if __name__ == "__main__":
    main()
